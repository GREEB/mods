Hero Select Plus v1.0 (built for Deadlock build 6745)

Shows hero names and classes on every card in hero select, adds a search box,
class filter buttons, and a details block for the hero you hover.

Install with Deadlock Mod Manager, or by hand:
  copy pak01_dir.vpk into  Deadlock/game/citadel/addons
  and rename it to the next free number (pak02_dir.vpk, pak03_dir.vpk, ...).

This mod replaces the hero select layout. If hero select looks wrong after a
game update, disable the mod until a rebuilt version is posted.
