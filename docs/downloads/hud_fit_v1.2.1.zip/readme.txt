HUD Fit v1.2.1 (built for Deadlock build 6746)

Live HUD layout editor: move, resize and de-stretch every HUD element, made for
4:3 stretched but useful on any resolution. Made to be used together
with "4:3 Video" (adds a 4x3 aspect ratio option to the video settings).

Open it in game: Esc -> HUD Fit (under Settings). Best in Explore NYC or a sandbox /
Hero Testing match: the hideout hides most of the HUD.
 - Click an element on screen to select it, drag to move, drag the yellow corner to resize.
 - W A S D nudge (Shift = 10 px), + / - resize. Done closes the editor.
 - Layers: show/hide, lock or reset each element.
 - HUD: scale all items, 4:3 stretch fix, filters, editor options, Reset all.
 - Test: sandbox buttons (damage, low health, death, level up, souls, enemy bot...)
   so you can see real UI states while arranging.
 - Presets: Default, Clean, up to 20 named layouts, export/import layout codes to share.
Layouts are saved on your PC through a tiny page in the game's own browser
(https://greeb.github.io/hudfit-storage/, no network access, nothing uploaded).

Install with Deadlock Mod Manager, or by hand:
  copy pak01_dir.vpk into  Deadlock/game/citadel/addons
  and rename it to the next free number (pak02_dir.vpk, pak03_dir.vpk, ...).

HUD Fit changes two game layouts (base_hud, hud_escape_menu). If the HUD looks
wrong after a game update, disable the mod until a rebuilt version is posted.
Updates: https://greeb.github.io/mods/
