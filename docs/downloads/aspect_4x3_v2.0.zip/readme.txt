4:3 Video v2.0

Adds a "4x3" button to Settings -> Video -> Aspect Ratio, next to 16:9, 16:10 and 21:9.
After picking it, the resolution list shows the 4:3 modes your graphics driver offers
(for higher 4:3 modes such as 1920x1440, add them as custom resolutions in your GPU driver first).

Unlike older 4:3 mods, the settings screen is never replaced: the button is added to the live
settings screen, so settings added by future game updates never go missing.

Install with Deadlock Mod Manager, or by hand:
  copy pak01_dir.vpk into  Deadlock/game/citadel/addons
  and rename it to the next free number (pak02_dir.vpk, pak03_dir.vpk, ...).

Made to be used together with HUD Fit (de-stretch / move / resize the HUD for 4:3 stretched).
